# Docker Bench for Security v1.8.0

The Docker Bench for Security is a script that checks for dozens of common best-practices around deploying Docker containers in production. The tests are all automated, and are based on the [CIS Docker Benchmark v1.8.0](https://www.cisecurity.org/benchmark/docker/).

This tool runs 118 automated security checks and generates DISA STIG-compliant Excel reports with actual audit command outputs.

---

## Table of Contents

- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [How to Use](#how-to-use)
  - [Method 1: Run Directly on Host](#method-1-run-directly-on-host)
  - [Method 2: Run via Docker Container](#method-2-run-via-docker-container)
  - [Method 3: Run on Remote Host via SSH](#method-3-run-on-remote-host-via-ssh)
- [Generating STIG Reports](#generating-stig-reports)
- [Understanding the Output](#understanding-the-output)
- [Command-Line Options](#command-line-options)
- [Check Categories](#check-categories)
- [File Structure](#file-structure)
- [Troubleshooting](#troubleshooting)

---

## Prerequisites

### For Running the Benchmark

| Requirement | Purpose |
|-------------|---------|
| Linux host | The benchmark must run on a Linux system with Docker |
| Docker 1.13.0+ | Docker daemon must be installed and running |
| Root/sudo access | Required to inspect Docker daemon and containers |
| Bash shell | The benchmark scripts are written in Bash |

### Optional Dependencies

| Dependency | Purpose |
|------------|---------|
| `jq` | JSON processing for some checks |
| `auditctl` | Audit rule verification (falls back to reading `/etc/audit/audit.rules`) |

### For Generating Reports

| Requirement | Purpose |
|-------------|---------|
| Python 3.x | Required to run `generate_report.py` |
| `openpyxl` | Python library for Excel file generation |

---

## Installation

### Step 1: Download the Tool

**Option A: Clone from repository**
```sh
git clone https://github.com/docker/docker-bench-security.git
cd docker-bench-security
```

**Option B: Copy files manually**

Copy the entire `docker-bench-security` folder to your target host. The following files and directories are required:

```
docker-bench-security/
├── docker-bench-security.sh    # REQUIRED - Main script
├── generate_report.py          # REQUIRED - Report generator
├── functions/                  # REQUIRED - All files in this directory
│   ├── functions_lib.sh
│   ├── helper_lib.sh
│   └── output_lib.sh
├── tests/                      # REQUIRED - All files in this directory
│   ├── 1_host_configuration.sh
│   ├── 2_docker_daemon_configuration.sh
│   ├── 3_docker_daemon_configuration_files.sh
│   ├── 4_container_images.sh
│   ├── 5_container_runtime.sh
│   ├── 6_docker_security_operations.sh
│   ├── 7_docker_swarm_configuration.sh
│   └── 99_community_checks.sh
├── Dockerfile                  # OPTIONAL - For containerized runs
└── docker-compose.yml          # OPTIONAL - For containerized runs
```

### Step 2: Set Permissions

```sh
chmod +x docker-bench-security.sh
chmod +x generate_report.py
```

### Step 3: Install Python Dependencies (for report generation)

```sh
pip install openpyxl
```

Or with pip3:
```sh
pip3 install openpyxl
```

---

## How to Use

### Method 1: Run Directly on Host

This is the simplest method. Run the benchmark directly on a Linux host where Docker is installed.

#### Step 1: Navigate to the tool directory

```sh
cd /path/to/docker-bench-security
```

#### Step 2: Run the benchmark with verbose mode

```sh
sudo sh docker-bench-security.sh -v
```

The `-v` flag enables verbose mode, which captures actual `docker inspect` output for each check. This is required for generating detailed STIG reports.

#### Step 3: Save output to a file

```sh
sudo sh docker-bench-security.sh -v > benchmark_output.txt 2>&1
```

This saves both stdout and stderr to `benchmark_output.txt`.

#### Step 4: Generate the STIG report

```sh
python generate_report.py --input benchmark_output.txt
```

Or specify an output directory:
```sh
python generate_report.py --input benchmark_output.txt --output /path/to/reports/
```

#### Step 5: Review the generated report

The script creates an Excel file named:
```
CIS_Docker_v1.8.0_STIG_<hostname>_<YYYYMMDD>_<HHMMSS>.xlsx
```

---

### Method 2: Run via Docker Container

Run the benchmark inside a Docker container. This method requires mounting host directories into the container.

#### Step 1: Build the Docker image

```sh
cd /path/to/docker-bench-security
docker build --no-cache -t docker-bench-security .
```

#### Step 2: Run the container

**Standard Linux:**
```sh
docker run --rm --net host --pid host --userns host --cap-add audit_control \
    -e DOCKER_CONTENT_TRUST=$DOCKER_CONTENT_TRUST \
    -v /etc:/etc:ro \
    -v /usr/bin/containerd:/usr/bin/containerd:ro \
    -v /usr/bin/runc:/usr/bin/runc:ro \
    -v /usr/lib/systemd:/usr/lib/systemd:ro \
    -v /var/lib:/var/lib:ro \
    -v /var/run/docker.sock:/var/run/docker.sock:ro \
    --label docker_bench_security \
    docker-bench-security -v
```

**Ubuntu/Debian:**
```sh
docker run --rm --net host --pid host --userns host --cap-add audit_control \
    -e DOCKER_CONTENT_TRUST=$DOCKER_CONTENT_TRUST \
    -v /etc:/etc:ro \
    -v /lib/systemd/system:/lib/systemd/system:ro \
    -v /usr/bin/containerd:/usr/bin/containerd:ro \
    -v /usr/bin/runc:/usr/bin/runc:ro \
    -v /usr/lib/systemd:/usr/lib/systemd:ro \
    -v /var/lib:/var/lib:ro \
    -v /var/run/docker.sock:/var/run/docker.sock:ro \
    --label docker_bench_security \
    docker-bench-security -v
```

**Amazon Linux / RHEL / CentOS:**
```sh
docker run --rm --net host --pid host --userns host --cap-add audit_control \
    -e DOCKER_CONTENT_TRUST=$DOCKER_CONTENT_TRUST \
    -v /etc:/etc:ro \
    -v /usr/bin/containerd:/usr/bin/containerd:ro \
    -v /usr/bin/runc:/usr/bin/runc:ro \
    -v /usr/lib/systemd:/usr/lib/systemd:ro \
    -v /var/lib:/var/lib:ro \
    -v /var/run/docker.sock:/var/run/docker.sock:ro \
    --label docker_bench_security \
    docker-bench-security -v
```

#### Step 3: Save output and generate report

```sh
docker run --rm --net host --pid host --userns host --cap-add audit_control \
    -e DOCKER_CONTENT_TRUST=$DOCKER_CONTENT_TRUST \
    -v /etc:/etc:ro \
    -v /usr/bin/containerd:/usr/bin/containerd:ro \
    -v /usr/bin/runc:/usr/bin/runc:ro \
    -v /usr/lib/systemd:/usr/lib/systemd:ro \
    -v /var/lib:/var/lib:ro \
    -v /var/run/docker.sock:/var/run/docker.sock:ro \
    --label docker_bench_security \
    docker-bench-security -v > benchmark_output.txt 2>&1

python generate_report.py --input benchmark_output.txt
```

#### Using Docker Compose

```sh
docker-compose run --rm docker-bench-security -v > benchmark_output.txt 2>&1
python generate_report.py --input benchmark_output.txt
```

#### Container Mount Explanation

| Mount | Purpose |
|-------|---------|
| `/etc:/etc:ro` | Access host configuration files (Docker daemon config, audit rules) |
| `/var/run/docker.sock` | Communicate with Docker daemon |
| `/var/lib:/var/lib:ro` | Access Docker data directory |
| `/usr/bin/containerd` | Check containerd binary |
| `/usr/bin/runc` | Check runc binary |
| `/usr/lib/systemd` | Check systemd unit files |
| `--net host` | Access host network namespace |
| `--pid host` | Access host process namespace |
| `--userns host` | Access host user namespace |
| `--cap-add audit_control` | Access audit subsystem |

---

### Method 3: Run on Remote Host via SSH

Run the benchmark on a remote host and generate the report locally.

#### Prerequisites

- SSH access to the remote host
- SSH key authentication configured
- Docker installed on the remote host
- The `docker-bench-security` folder copied to the remote host

#### Step 1: Copy files to remote host

```sh
scp -r -i ~/.ssh/your_key.pem docker-bench-security/ user@remote-host:/home/user/
```

#### Step 2: Run benchmark and generate report in one command

```sh
python generate_report.py --remote user@remote-host --key ~/.ssh/your_key.pem
```

This will:
1. SSH to the remote host
2. Run `docker-bench-security.sh -v`
3. Download the output
4. Generate the Excel report locally

#### Step 3: Specify custom paths (optional)

```sh
python generate_report.py \
    --remote user@remote-host \
    --key ~/.ssh/your_key.pem \
    --output /local/path/to/reports/ \
    --hostname "production-server-01"
```

---

## Generating STIG Reports

### Report Generator Options

```sh
python generate_report.py --help

Options:
  --input, -i     Path to benchmark output file (local mode)
  --output, -o    Output directory for Excel report (default: current directory)
  --template, -t  Path to custom CIS Excel template
  --remote, -r    Remote host in format user@hostname
  --key, -k       SSH private key file for remote execution
  --hostname, -H  Custom hostname for report filename (default: localhost)
```

### Examples

**Generate from local output file:**
```sh
python generate_report.py --input benchmark_output.txt
```

**Generate with custom output directory:**
```sh
python generate_report.py --input benchmark_output.txt --output /reports/docker/
```

**Generate from remote host:**
```sh
python generate_report.py --remote ec2-user@10.0.1.50 --key ~/.ssh/aws.pem
```

**Generate with custom hostname in filename:**
```sh
python generate_report.py --input benchmark_output.txt --hostname webserver-prod-01
```

---

## Understanding the Output

### Console Output

When running with `-v` verbose mode, you'll see output like:

```
[INFO] 5.11 - Ensure memory usage for container is limited
[WARN] 5.11 - Container 'my-app' does not have memory limits set
[OUTPUT] my-app: Memory=0 MemorySwap=0;
```

| Prefix | Meaning |
|--------|---------|
| `[INFO]` | Check description |
| `[PASS]` | Check passed - compliant |
| `[WARN]` | Check failed - remediation needed |
| `[NOTE]` | Informational - not a pass/fail |
| `[OUTPUT]` | Actual audit command output (verbose mode only) |

### Excel Report Columns

| Column | Content |
|--------|---------|
| A | Check ID (e.g., 5.11) |
| B | Check Description |
| C | STIG Status |
| D | Audit Command |
| E | Comments (includes AUDIT COMMAND, AUDIT OUTPUT, REASONING) |

### STIG Status Values

| Status | Meaning | Action Required |
|--------|---------|-----------------|
| **Not a Finding** | Check passed | None - compliant |
| **Open** | Check failed | Remediation required |
| **Not Applicable** | Check doesn't apply | None - document why |
| **Not Reviewed** | Manual verification needed | Manual review required |

### Example Report Output

For check 5.11 (Memory limits), the Comments column (E) will contain:

```
AUDIT COMMAND: docker ps --quiet | xargs docker inspect --format "{{ .Id }}: Memory={{ .HostConfig.Memory }}"

AUDIT OUTPUT: my-app: Memory=0 MemorySwap=0; nginx: Memory=536870912 MemorySwap=1073741824;

REASONING: Container 'my-app' does not have memory limits configured. Memory=0 indicates unlimited memory usage.
```

---

## Command-Line Options

### Benchmark Script Options

```sh
sudo sh docker-bench-security.sh [OPTIONS]

Options:
  -v           Enable verbose mode - capture actual audit command results
               RECOMMENDED for STIG report generation

  -b           Disable colored output (useful for log files)

  -h           Display help message

  -l FILE      Log output to FILE in addition to stdout
               Example: -l /var/log/docker-bench.log

  -c CHECK     Run only specific check(s), comma separated
               Example: -c container_runtime
               Example: -c check_5_11,check_5_12

  -e CHECK     Exclude specific check(s), comma separated
               Example: -e docker_enterprise_configuration

  -i PATTERN   Only check containers/images matching PATTERN
               Example: -i "prod-*"

  -x PATTERN   Exclude containers/images matching PATTERN
               Example: -x "test-*,dev-*"

  -t LABEL     Only check containers/images with LABEL
               Example: -t "environment=production"

  -n LIMIT     Limit number of items in JSON output

  -p           Disable printing of remediation measures

  -u USERS     Comma-separated list of trusted Docker users
               Example: -u "admin,deployer"
```

### Usage Examples

**Run all checks with verbose output:**
```sh
sudo sh docker-bench-security.sh -v
```

**Run only Section 5 (Container Runtime) checks:**
```sh
sudo sh docker-bench-security.sh -c container_runtime -v
```

**Run all except Docker Swarm checks:**
```sh
sudo sh docker-bench-security.sh -e docker_swarm_configuration -v
```

**Check only production containers:**
```sh
sudo sh docker-bench-security.sh -i "prod-*" -v
```

**Exclude test containers:**
```sh
sudo sh docker-bench-security.sh -x "test-*,dev-*,*-debug" -v
```

**Log to file while displaying output:**
```sh
sudo sh docker-bench-security.sh -v -l /var/log/docker-bench.log
```

**Run specific checks only:**
```sh
sudo sh docker-bench-security.sh -c check_5_11,check_5_12,check_5_13 -v
```

---

## Check Categories

The benchmark includes 118 checks across 7 sections:

| Section | Description | Checks | Examples |
|---------|-------------|--------|----------|
| 1 | Host Configuration | 22 | Kernel hardening, audit rules, Docker partition |
| 2 | Docker Daemon Configuration | 19 | Network settings, logging, TLS, user namespace |
| 3 | Docker Daemon Configuration Files | 24 | File permissions on Docker config files |
| 4 | Container Images and Build File | 12 | Image scanning, user settings, HEALTHCHECK |
| 5 | Container Runtime | 32 | Memory limits, capabilities, privileges, mounts |
| 6 | Docker Security Operations | 2 | Security policies, container sprawl |
| 7 | Docker Swarm Configuration | 9 | Swarm mode, secrets, overlay networks |
| **Total** | | **118** | |

### Section 5 Checks (Container Runtime) - Detailed

These checks inspect running containers:

| Check | Description | What It Checks |
|-------|-------------|----------------|
| 5.1 | Swarm mode not enabled | `docker info` Swarm state |
| 5.2 | AppArmor profile enabled | `AppArmorProfile` |
| 5.3 | SELinux options set | `SecurityOpt` |
| 5.4 | Kernel capabilities restricted | `CapAdd`, `CapDrop` |
| 5.5 | Privileged mode not used | `Privileged` |
| 5.6 | Sensitive host dirs not mounted | `Mounts` |
| 5.7 | SSH not running in container | `ps -el \| grep sshd` |
| 5.8 | Privileged ports not mapped | Ports < 1024 |
| 5.9 | Only needed ports open | `docker port` |
| 5.10 | Host network not shared | `NetworkMode` |
| 5.11 | Memory limits set | `Memory`, `MemorySwap` |
| 5.12 | CPU priority set | `CpuShares`, `NanoCpus` |
| 5.13 | Root filesystem read-only | `ReadonlyRootfs` |
| 5.14 | Traffic bound to interface | Port binding to 0.0.0.0 |
| 5.15 | Restart policy set | `RestartPolicy`, `MaxRetry` |
| 5.16 | Host PID not shared | `PidMode` |
| 5.17 | Host IPC not shared | `IpcMode` |
| 5.18 | Host devices not exposed | `Devices` |
| 5.19 | Ulimits overwritten | `Ulimits` |
| 5.20 | Mount propagation not shared | `Propagation` |
| 5.21 | Host UTS not shared | `UTSMode` |
| 5.22 | Seccomp profile not disabled | `SecurityOpt` |
| 5.23 | docker exec without --privileged | Manual/audit |
| 5.24 | docker exec without --user=root | Manual/audit |
| 5.25 | cgroup usage confirmed | `CgroupParent` |
| 5.26 | No new privileges | `SecurityOpt` |
| 5.27 | Health check configured | `Health.Status` |
| 5.28 | Image version pinned | Manual review |
| 5.29 | PID cgroup limit set | `PidsLimit` |
| 5.30 | Docker default bridge not used | `NetworkMode` |
| 5.31 | User namespace not shared | `UsernsMode` |
| 5.32 | Docker socket not mounted | `Mounts` |

---

## File Structure

```
docker-bench-security/
│
├── docker-bench-security.sh      # Main benchmark script
│                                  # Entry point - sources all other scripts
│
├── generate_report.py            # STIG-style Excel report generator
│                                  # Parses benchmark output, creates .xlsx
│
├── functions/
│   ├── functions_lib.sh          # Core benchmark functions
│   │                              # check(), info(), pass(), warn(), note()
│   ├── helper_lib.sh             # Helper utilities
│   │                              # get_docker_configuration_file(), etc.
│   └── output_lib.sh             # Output formatting functions
│                                  # audit_output() for verbose mode
│
├── tests/
│   ├── 1_host_configuration.sh           # Section 1: 22 checks
│   ├── 2_docker_daemon_configuration.sh  # Section 2: 19 checks
│   ├── 3_docker_daemon_configuration_files.sh  # Section 3: 24 checks
│   ├── 4_container_images.sh             # Section 4: 12 checks
│   ├── 5_container_runtime.sh            # Section 5: 32 checks
│   ├── 6_docker_security_operations.sh   # Section 6: 2 checks
│   ├── 7_docker_swarm_configuration.sh   # Section 7: 9 checks
│   └── 99_community_checks.sh            # Community-contributed checks
│
├── Dockerfile                    # Build container image
├── docker-compose.yml            # Docker Compose configuration
├── img/                          # Documentation images
├── LICENSE.md                    # Apache License 2.0
├── CONTRIBUTING.md               # Contribution guidelines
├── CONTRIBUTORS.md               # List of contributors
├── MAINTAINERS                   # Project maintainers
├── Vagrantfile                   # Vagrant configuration
└── README.md                     # This file
```

---

## Troubleshooting

### Common Issues

**Issue: "Permission denied" when running benchmark**
```
Solution: Run with sudo
$ sudo sh docker-bench-security.sh -v
```

**Issue: "Cannot connect to Docker daemon"**
```
Solution: Ensure Docker is running and you have permissions
$ sudo systemctl status docker
$ sudo usermod -aG docker $USER
```

**Issue: "No containers to check" in Section 5**
```
Solution: Start some containers before running the benchmark
$ docker run -d --name test-container nginx
$ sudo sh docker-bench-security.sh -v
```

**Issue: Python reports "ModuleNotFoundError: No module named 'openpyxl'"**
```
Solution: Install the openpyxl package
$ pip install openpyxl
# or
$ pip3 install openpyxl
```

**Issue: SSH connection fails for remote execution**
```
Solution: Check SSH key permissions and connectivity
$ chmod 600 ~/.ssh/your_key.pem
$ ssh -i ~/.ssh/your_key.pem user@host "echo test"
```

**Issue: Report shows "Not Reviewed" for all checks**
```
Solution: Ensure you ran with -v verbose flag
$ sudo sh docker-bench-security.sh -v > output.txt 2>&1
```

### Verbose Mode Not Working

If `[OUTPUT]` lines are not appearing:

1. Verify you're using the `-v` flag
2. Check that containers are running: `docker ps`
3. Ensure you have the updated `output_lib.sh` with `audit_output()` function

### Empty or Missing Audit Output

For Section 5 checks to show actual values:

1. Running containers must exist
2. The benchmark must be run with `-v` flag
3. The user must have permission to `docker inspect`

---

## What's New in v1.8.0

### Verbose Mode (-v flag)
Captures actual `docker inspect` results for each check, enabling detailed STIG reports.

### Actual Audit Output
All 118 checks now output real inspection results:

| Check | Example Output |
|-------|----------------|
| 5.4 | `my-container: CapAdd=[] CapDrop=[ALL];` |
| 5.5 | `my-container: Privileged=false;` |
| 5.11 | `my-container: Memory=536870912 MemorySwap=1073741824;` |
| 5.15 | `my-container: RestartPolicy=on-failure MaxRetry=5;` |
| 5.26 | `my-container: SecurityOpt=[no-new-privileges];` |
| 5.29 | `my-container: PidsLimit=100;` |

### New Checks in v1.8.0
- **2.7**: Ensure devicemapper storage driver is not used
- **2.19**: Ensure experimental features are not in production

---

## Version History

| Release | CIS Benchmark | Key Changes |
|:---:|:---:|:---|
| **1.8.1** | **1.8.0** | Fix 1.1.9 audit command (docker.sock), dynamic systemd paths for 3.1-3.4 |
| 1.8.0 | 1.8.0 | Verbose mode, STIG-style reports, actual audit output capture |
| 1.6.0 | 1.6.0 | Previous stable release |

---

## License

Apache License 2.0

---

## Quick Reference

```sh
# Install
git clone https://github.com/docker/docker-bench-security.git
cd docker-bench-security
pip install openpyxl

# Run benchmark (save output)
sudo sh docker-bench-security.sh -v > benchmark_output.txt 2>&1

# Generate STIG report
python generate_report.py --input benchmark_output.txt

# One-liner for remote host
python generate_report.py --remote user@host --key ~/.ssh/key.pem
```
