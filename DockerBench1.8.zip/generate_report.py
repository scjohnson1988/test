#!/usr/bin/env python3
"""
Docker Bench Security Report Generator (STIG-Style)
Generates a STIG-style checklist from docker-bench-security results.

Usage:
    python generate_report.py [--input <results_file>] [--output <output_dir>]

Options:
    --input     Path to benchmark output file
    --output    Output directory for the report (default: current directory)
    --template  Path to CIS Excel template
    --remote    Run benchmark on remote host via SSH (format: user@host)
    --key       SSH key file for remote execution
    --hostname  Hostname to include in report filename
"""

import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import subprocess
import sys
import re
import argparse
from datetime import datetime
from pathlib import Path


# STIG-style status values
STATUS_NOT_REVIEWED = "Not Reviewed"
STATUS_NOT_APPLICABLE = "Not Applicable"
STATUS_NOT_A_FINDING = "Not a Finding"
STATUS_OPEN = "Open"

# Mapping of benchmark results to STIG status
STATUS_MAPPING = {
    'PASS': STATUS_NOT_A_FINDING,
    'WARN': STATUS_OPEN,
    'INFO': STATUS_NOT_APPLICABLE,
    'NOTE': STATUS_NOT_REVIEWED,
}

# Color fills for status cells
STATUS_COLORS = {
    STATUS_NOT_A_FINDING: PatternFill(start_color='90EE90', end_color='90EE90', fill_type='solid'),  # Green
    STATUS_OPEN: PatternFill(start_color='FF6B6B', end_color='FF6B6B', fill_type='solid'),  # Red
    STATUS_NOT_APPLICABLE: PatternFill(start_color='D3D3D3', end_color='D3D3D3', fill_type='solid'),  # Gray
    STATUS_NOT_REVIEWED: PatternFill(start_color='FFFF99', end_color='FFFF99', fill_type='solid'),  # Yellow
}

# Audit commands for each CIS check (extracted from CIS Docker Benchmark v1.8.0)
AUDIT_COMMANDS = {
    # Section 1 - Host Configuration
    '1.1.1': 'mountpoint -- "$(docker info -f \'{{ .DockerRootDir }}\')"',
    '1.1.2': 'getent group docker',
    '1.1.3': 'auditctl -l | grep /usr/bin/dockerd',
    '1.1.4': 'auditctl -l | grep /run/containerd',
    '1.1.5': 'auditctl -l | grep /var/lib/docker',
    '1.1.6': 'auditctl -l | grep /etc/docker',
    '1.1.7': 'auditctl -l | grep docker.service',
    '1.1.8': 'auditctl -l | grep containerd.sock',
    '1.1.9': 'auditctl -l | grep docker.sock',
    '1.1.10': 'auditctl -l | grep /etc/default/docker',
    '1.1.11': 'auditctl -l | grep /etc/docker/daemon.json',
    '1.1.12': 'auditctl -l | grep /etc/containerd/config.toml',
    '1.1.13': 'auditctl -l | grep /etc/sysconfig/docker',
    '1.1.14': 'auditctl -l | grep /usr/bin/containerd',
    '1.1.15': 'auditctl -l | grep /usr/bin/containerd-shim',
    '1.1.16': 'auditctl -l | grep /usr/bin/containerd-shim-runc-v1',
    '1.1.17': 'auditctl -l | grep /usr/bin/containerd-shim-runc-v2',
    '1.1.18': 'auditctl -l | grep /usr/bin/runc',
    '1.2.1': 'Manual review required - Verify host hardening',
    '1.2.2': 'docker version',

    # Section 2 - Docker Daemon Configuration
    '2.1': 'ps -ef | grep dockerd',
    '2.2': 'docker network ls --quiet | xargs docker network inspect --format "{{ .Name }}: {{ .Options }}"',
    '2.3': 'ps -ef | grep dockerd | grep log-level',
    '2.4': 'ps -ef | grep dockerd | grep iptables',
    '2.5': 'docker info --format "{{ .RegistryConfig.InsecureRegistryCIDRs }}"',
    '2.6': 'docker info --format "Storage Driver: {{ .Driver }}"',
    '2.7': 'docker info --format "Storage Driver: {{ .Driver }}"',
    '2.8': 'ps -ef | grep dockerd | grep -E "tlsverify|tlscacert|tlscert|tlskey"',
    '2.9': 'ps -ef | grep dockerd | grep default-ulimit',
    '2.10': 'ps -ef | grep dockerd | grep userns-remap',
    '2.11': 'ps -ef | grep dockerd | grep cgroup-parent',
    '2.12': 'ps -ef | grep dockerd | grep "storage-opt.*dm.basesize"',
    '2.13': 'ps -ef | grep dockerd | grep authorization-plugin',
    '2.14': 'docker info --format "{{ .LoggingDriver }}"',
    '2.15': 'ps -ef | grep dockerd | grep no-new-privileges',
    '2.16': 'docker info --format "{{ .LiveRestoreEnabled }}"',
    '2.17': 'ps -ef | grep dockerd | grep userland-proxy',
    '2.18': 'docker info --format "{{ .SecurityOptions }}"',
    '2.19': 'docker version -f "{{.Server.Experimental}}"',

    # Section 3 - Docker Daemon Configuration Files
    # Note: Using dynamic path detection via systemctl for portability across distros
    '3.1': 'stat -c %U:%G $(systemctl show -p FragmentPath docker.service | cut -d= -f2)',
    '3.2': 'stat -c %a $(systemctl show -p FragmentPath docker.service | cut -d= -f2)',
    '3.3': 'stat -c %U:%G $(systemctl show -p FragmentPath docker.socket | cut -d= -f2)',
    '3.4': 'stat -c %a $(systemctl show -p FragmentPath docker.socket | cut -d= -f2)',
    '3.5': 'stat -c %U:%G /etc/docker',
    '3.6': 'stat -c %a /etc/docker',
    '3.7': 'stat -c %U:%G /etc/docker/certs.d/*',
    '3.8': 'stat -c %a /etc/docker/certs.d/*',
    '3.9': 'stat -c %U:%G <TLS CA cert path>',
    '3.10': 'stat -c %a <TLS CA cert path>',
    '3.11': 'stat -c %U:%G <TLS server cert path>',
    '3.12': 'stat -c %a <TLS server cert path>',
    '3.13': 'stat -c %U:%G <TLS server key path>',
    '3.14': 'stat -c %a <TLS server key path>',
    '3.15': 'stat -c %U:%G /var/run/docker.sock',
    '3.16': 'stat -c %a /var/run/docker.sock',
    '3.17': 'stat -c %U:%G /etc/docker/daemon.json',
    '3.18': 'stat -c %a /etc/docker/daemon.json',
    '3.19': 'stat -c %U:%G /etc/default/docker',
    '3.20': 'stat -c %a /etc/default/docker',
    '3.21': 'stat -c %a /etc/sysconfig/docker',
    '3.22': 'stat -c %U:%G /etc/sysconfig/docker',
    '3.23': 'stat -c %U:%G /run/containerd/containerd.sock',
    '3.24': 'stat -c %a /run/containerd/containerd.sock',

    # Section 4 - Container Images
    '4.1': 'docker ps --quiet | xargs -I {} docker inspect --format "{{ .Id }}: User={{ .Config.User }}" {}',
    '4.2': 'Manual review - Verify trusted base images',
    '4.3': 'Manual review - Verify no unnecessary packages',
    '4.4': 'Manual review - Verify images scanned for vulnerabilities',
    '4.5': 'echo $DOCKER_CONTENT_TRUST',
    '4.6': 'docker images --quiet | xargs docker inspect --format "{{ .Id }}: {{ .Config.Healthcheck }}"',
    '4.7': 'docker images --quiet | xargs docker history --no-trunc | grep -E "apt-get update|yum update"',
    '4.8': 'Manual review - Check setuid/setgid permissions',
    '4.9': 'docker images --quiet | xargs docker history --no-trunc | grep -E "^ADD"',
    '4.10': 'Manual review - Check for secrets in Dockerfiles',
    '4.11': 'Manual review - Verify packages are from trusted sources',
    '4.12': 'Manual review - Verify signed artifacts',

    # Section 5 - Container Runtime (CIS Docker Benchmark v1.8.0)
    '5.1': 'docker info --format "{{ .Swarm.LocalNodeState }}"',
    '5.2': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: AppArmorProfile={{ .AppArmorProfile }}"',
    '5.3': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: SecurityOpt={{ .HostConfig.SecurityOpt }}"',
    '5.4': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: CapAdd={{ .HostConfig.CapAdd }} CapDrop={{ .HostConfig.CapDrop }}"',
    '5.5': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: Privileged={{ .HostConfig.Privileged }}"',
    '5.6': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: Mounts={{ .Mounts }}"',
    '5.7': 'docker exec <container> ps -el | grep sshd',
    '5.8': 'docker port <container> (check for ports < 1024)',
    '5.9': 'docker port <container>',
    '5.10': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: NetworkMode={{ .HostConfig.NetworkMode }}"',
    '5.11': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: Memory={{ .HostConfig.Memory }}"',
    '5.12': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: CpuShares={{ .HostConfig.CpuShares }} NanoCpus={{ .HostConfig.NanoCpus }}"',
    '5.13': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: ReadonlyRootfs={{ .HostConfig.ReadonlyRootfs }}"',
    '5.14': 'docker port <container> (check for 0.0.0.0 binding)',
    '5.15': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: RestartPolicy={{ .HostConfig.RestartPolicy.Name }} MaxRetry={{ .HostConfig.RestartPolicy.MaximumRetryCount }}"',
    '5.16': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: PidMode={{ .HostConfig.PidMode }}"',
    '5.17': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: IpcMode={{ .HostConfig.IpcMode }}"',
    '5.18': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: Devices={{ .HostConfig.Devices }}"',
    '5.19': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: Ulimits={{ .HostConfig.Ulimits }}"',
    '5.20': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: Propagation={{ range .Mounts }}{{ .Propagation }}{{ end }}"',
    '5.21': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: UTSMode={{ .HostConfig.UTSMode }}"',
    '5.22': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: SecurityOpt={{ .HostConfig.SecurityOpt }}"',
    '5.23': 'Review auditd logs for docker exec --privileged commands',
    '5.24': 'Review auditd logs for docker exec --user=root commands',
    '5.25': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: CgroupParent={{ .HostConfig.CgroupParent }}"',
    '5.26': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: SecurityOpt={{ .HostConfig.SecurityOpt }}" | grep no-new-privileges',
    '5.27': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: Health={{ .State.Health.Status }}"',
    '5.28': 'Manual review - Verify image version pinning',
    '5.29': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: PidsLimit={{ .HostConfig.PidsLimit }}"',
    '5.30': 'docker network inspect bridge --format "{{ .Containers }}"',
    '5.31': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: UsernsMode={{ .HostConfig.UsernsMode }}"',
    '5.32': 'docker ps --quiet | xargs docker inspect --format "{{ .Id }}: Mounts={{ .Mounts }}" | grep docker.sock',

    # Section 6 - Docker Security Operations
    '6.1': 'docker images --quiet | wc -l',
    '6.2': 'docker ps --all --quiet | wc -l',

    # Section 7 - Docker Swarm Configuration
    '7.1': 'docker node ls --filter "role=manager" | wc -l',
    '7.2': 'docker info --format "{{ .Swarm.NodeAddr }}"',
    '7.3': 'docker network ls --filter driver=overlay --quiet | xargs docker network inspect --format "{{ .Name }}: {{ .Options }}"',
    '7.4': 'docker secret ls',
    '7.5': 'docker swarm unlock-key',
    '7.6': 'Manual review - Verify auto-lock key rotation',
    '7.7': 'docker info --format "{{ .Swarm.Cluster.Spec.CAConfig.NodeCertExpiry }}"',
    '7.8': 'Manual review - Verify CA certificate rotation',
    '7.9': 'docker info --format "{{ .Swarm.NodeAddr }}"',
}


def normalize_cis_id(cell_value, row_num=None, description=None):
    """Convert Excel cell value to normalized CIS ID string."""
    if cell_value is None:
        return None

    if isinstance(cell_value, datetime):
        year = cell_value.year
        if year >= 2000:
            return f"1.1.{year - 2000}"
        return str(cell_value)

    if isinstance(cell_value, (int, float)):
        str_val = str(cell_value)
        if description:
            desc_lower = description.lower()
            # Handle 2.10 (user namespace) stored as 2.1
            if str_val == "2.1" and ("user namespace" in desc_lower or "userns" in desc_lower):
                return "2.10"
            # Handle 5.10 (network namespace) stored as 5.1
            elif str_val == "5.1" and "network namespace" in desc_lower:
                return "5.10"
            # Handle 5.20 (mount propagation) stored as 5.2
            elif str_val == "5.2" and "mount propagation" in desc_lower:
                return "5.20"
            # Handle 5.30 (docker0 bridge) stored as 5.3
            elif str_val == "5.3" and "docker0" in desc_lower:
                return "5.30"
        return str_val

    return str(cell_value).strip()


def run_benchmark_remote(host, key_file):
    """Run docker-bench-security on a remote host via SSH."""
    ssh_cmd = ["ssh", "-o", "StrictHostKeyChecking=accept-new"]
    if key_file:
        ssh_cmd.extend(["-i", key_file])
    ssh_cmd.append(host)
    ssh_cmd.append("cd ~/DockerBench1.8 && sudo ./docker-bench-security.sh 2>&1")

    result = subprocess.run(ssh_cmd, capture_output=True, text=True)
    return result.stdout


def parse_benchmark_output(output):
    """Parse the benchmark output and extract results with details."""
    results = {}
    clean_output = re.sub(r'\x1b\[[0-9;]*m', '', output)

    pattern = r'\[(PASS|WARN|INFO|NOTE)\]\s+(\d+(?:\.\d+)*)\s+-\s+(.+?)(?:\s*$)'
    output_pattern = r'\[OUTPUT\]\s+(.+)$'

    lines = clean_output.split('\n')
    current_check_id = None
    pending_output = None  # Store [OUTPUT] that appears before check result

    for i, line in enumerate(lines):
        match = re.search(pattern, line)
        if match:
            status = match.group(1)
            check_id = match.group(2)
            description = match.group(3).strip()
            current_check_id = check_id

            results[check_id] = {
                'status': status,
                'description': description,
                'details': [],
                'audit_output': ''
            }

            # If there was a pending [OUTPUT] line, associate it with this check
            if pending_output:
                results[check_id]['audit_output'] = pending_output
                pending_output = None

        # Capture [OUTPUT] lines (verbose mode)
        # These appear BEFORE the check result, so store as pending
        elif '[OUTPUT]' in line:
            output_match = re.search(output_pattern, line)
            if output_match:
                pending_output = output_match.group(1).strip()

        # Capture detail lines (the * lines) - these appear AFTER the check result
        elif current_check_id and '*' in line:
            detail_match = re.search(r'\*\s*(.+)$', line)
            if detail_match and current_check_id in results:
                results[current_check_id]['details'].append(detail_match.group(1).strip())

    return results


# Reasoning explanations for each status type
REASONING_TEMPLATES = {
    'PASS': {
        'default': "The check passed because the Docker configuration meets the CIS Benchmark requirement.",
        'storage': "The storage driver in use is not {driver}, which is the recommended configuration.",
        'permissions': "File/directory permissions and ownership are correctly configured per CIS requirements.",
        'not_listening': "Docker daemon is not exposed on TCP, which is acceptable when remote management is not required.",
        'not_enabled': "This feature is not enabled, which is the secure default configuration.",
        'swarm_disabled': "Swarm mode is not enabled on this host, so this swarm-specific check passes by default.",
    },
    'WARN': {
        'default': "The check failed because the Docker configuration does not meet the CIS Benchmark requirement. Remediation is recommended.",
        'audit': "Audit rules are not configured for this file/directory. Configure auditd to monitor Docker-related files.",
        'partition': "Docker storage is not on a separate partition. Consider creating a dedicated partition for /var/lib/docker.",
        'network': "Inter-container communication on the default bridge is not restricted. Consider using --icc=false.",
        'privileges': "Containers can acquire new privileges. Configure --no-new-privileges in daemon.json.",
        'content_trust': "Docker Content Trust is not enabled. Set DOCKER_CONTENT_TRUST=1 environment variable.",
    },
    'INFO': {
        'default': "This is an informational check. The configuration item was not found or is not applicable to this environment.",
        'file_not_found': "The file or directory does not exist on this system. This check is not applicable.",
        'no_containers': "No containers are currently running. This runtime check cannot be evaluated.",
        'no_tls': "TLS is not configured. This is acceptable if Docker daemon is not exposed remotely.",
    },
    'NOTE': {
        'default': "This check requires manual review and cannot be automatically verified.",
        'manual': "Manual verification is required. Review the configuration against CIS Benchmark guidance.",
    },
}


def get_reasoning(check_id, result):
    """Generate appropriate reasoning based on check ID and result."""
    status = result['status']
    description = result.get('description', '').lower()
    details = result.get('details', [])
    details_text = ' '.join(details).lower() if details else ''

    templates = REASONING_TEMPLATES.get(status, {})

    # Select appropriate reasoning based on check context
    if status == 'PASS':
        if 'swarm mode not enabled' in description or 'swarm mode not enabled' in details_text:
            return templates.get('swarm_disabled', templates['default'])
        if 'storage driver' in description:
            return templates.get('storage', templates['default']).format(driver='devicemapper/aufs')
        if 'permission' in description or 'ownership' in description:
            return templates.get('permissions', templates['default'])
        if 'not listening on tcp' in details_text:
            return templates.get('not_listening', templates['default'])

    elif status == 'WARN':
        if 'audit' in description:
            return templates.get('audit', templates['default'])
        if 'partition' in description:
            return templates.get('partition', templates['default'])
        if 'network traffic' in description or 'icc' in description:
            return templates.get('network', templates['default'])
        if 'new privileges' in description:
            return templates.get('privileges', templates['default'])
        if 'content trust' in description:
            return templates.get('content_trust', templates['default'])

    elif status == 'INFO':
        if 'file not found' in details_text or 'directory not found' in details_text:
            return templates.get('file_not_found', templates['default'])
        if 'no containers' in details_text:
            return templates.get('no_containers', templates['default'])
        if 'no tls' in details_text or 'not listening on tcp' in details_text:
            return templates.get('no_tls', templates['default'])

    elif status == 'NOTE':
        return templates.get('manual', templates['default'])

    return templates.get('default', "Review required.")


def format_finding_details(result, stig_status, timestamp):
    """Format the finding details with status prefix, benchmark output, and timestamp."""
    lines = []

    # Add status prefix and the benchmark status line
    lines.append(f"{stig_status}: [{result['status']}] {result.get('description', 'N/A')}")

    # Add any detail lines
    if result['details']:
        for detail in result['details']:
            lines.append(f"  * {detail}")

    # Add timestamp at the end
    lines.append(f"({timestamp})")

    return '\n'.join(lines)


def format_comment(check_id, result):
    """Format the comment with audit command, output, and reasoning."""
    lines = []

    # Add audit command
    audit_cmd = AUDIT_COMMANDS.get(check_id, 'Manual review required')
    lines.append("AUDIT COMMAND:")
    lines.append(audit_cmd)
    lines.append("")

    # Add audit output (prefer verbose [OUTPUT] if available, then details, then default)
    lines.append("AUDIT OUTPUT:")
    if result.get('audit_output'):
        # Verbose mode output captured from [OUTPUT] lines
        lines.append(result['audit_output'])
    elif result['details']:
        # Details contain the actual command output
        for detail in result['details']:
            lines.append(detail)
    else:
        # No output captured - indicate based on status
        status = result['status']
        if status == 'PASS':
            lines.append("(No issues found - configuration is compliant)")
        elif status == 'WARN':
            lines.append("(No output returned or non-compliant configuration detected)")
        elif status == 'INFO':
            lines.append("(Informational - no specific output)")
        elif status == 'NOTE':
            lines.append("(Manual verification required)")
    lines.append("")

    # Add reasoning for the finding
    lines.append("REASONING:")
    reasoning = get_reasoning(check_id, result)
    lines.append(reasoning)

    return '\n'.join(lines)


def populate_excel(template_path, results, output_path, hostname=""):
    """Populate the Excel template with STIG-style results."""
    wb = openpyxl.load_workbook(template_path)
    ws = wb.active

    # Column indices
    id_col = 1
    desc_col = 2
    status_col = 3  # "Status" column - will have our 4 options
    details_col = 4  # "Finding Details" - will be empty or brief note
    comments_col = 5  # "Comments" - will have command and output

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    matched_count = 0

    # Update header for clarity
    ws.cell(row=1, column=status_col).value = "Status"
    ws.cell(row=1, column=details_col).value = "Finding Details"
    ws.cell(row=1, column=comments_col).value = "Comments"

    # First pass: fix CIS ID formatting (datetime and float precision issues)
    for row_num in range(2, ws.max_row + 1):
        cell = ws.cell(row=row_num, column=id_col)
        desc = ws.cell(row=row_num, column=desc_col).value
        normalized_id = normalize_cis_id(cell.value, row_num, desc)
        if normalized_id:
            # Fix datetime values (1.1.10 stored as dates)
            if isinstance(cell.value, datetime):
                cell.value = normalized_id
                cell.number_format = '@'
            # Fix float precision issues (2.10 stored as 2.1)
            elif isinstance(cell.value, float) and normalized_id != str(cell.value):
                cell.value = normalized_id
                cell.number_format = '@'

    # Second pass: populate results
    for row_num in range(2, ws.max_row + 1):
        cell_id = ws.cell(row=row_num, column=id_col).value
        desc = ws.cell(row=row_num, column=desc_col).value

        if cell_id is None:
            continue

        check_id = normalize_cis_id(cell_id, row_num, desc)

        # Skip title rows
        current_status = ws.cell(row=row_num, column=status_col).value
        if current_status == 'TITLE':
            continue

        # Look up result
        if check_id in results:
            result = results[check_id]

            # Set STIG-style status
            status = STATUS_MAPPING.get(result['status'], STATUS_NOT_REVIEWED)
            status_cell = ws.cell(row=row_num, column=status_col)
            status_cell.value = status

            # Apply color
            if status in STATUS_COLORS:
                status_cell.fill = STATUS_COLORS[status]

            # Set finding details (status prefix + benchmark output + timestamp)
            finding_details = format_finding_details(result, status, timestamp)
            details_cell = ws.cell(row=row_num, column=details_col)
            details_cell.value = finding_details
            details_cell.alignment = Alignment(wrap_text=True, vertical='top')

            # Set comment with audit command and reasoning
            comment = format_comment(check_id, result)
            comment_cell = ws.cell(row=row_num, column=comments_col)
            comment_cell.value = comment
            comment_cell.alignment = Alignment(wrap_text=True, vertical='top')

            matched_count += 1
        else:
            # Not scanned - mark as Not Reviewed
            if check_id and '.' in str(check_id):
                status_cell = ws.cell(row=row_num, column=status_col)
                if not status_cell.value or status_cell.value not in ['TITLE']:
                    status_cell.value = STATUS_NOT_REVIEWED
                    status_cell.fill = STATUS_COLORS[STATUS_NOT_REVIEWED]

    # Adjust column widths
    ws.column_dimensions['C'].width = 25
    ws.column_dimensions['D'].width = 45
    ws.column_dimensions['E'].width = 60

    # Set row heights for better readability
    for row_num in range(2, ws.max_row + 1):
        ws.row_dimensions[row_num].height = 60

    wb.save(output_path)
    print(f"Report saved to: {output_path}")
    print(f"Matched {matched_count} checks")

    return output_path


def main():
    parser = argparse.ArgumentParser(description='Generate STIG-style Docker Bench Security Report')
    parser.add_argument('--input', '-i', help='Path to benchmark output file')
    parser.add_argument('--output', '-o', default='.', help='Output directory')
    parser.add_argument('--template', '-t', help='Path to CIS Excel template')
    parser.add_argument('--remote', '-r', help='Run on remote host (user@host)')
    parser.add_argument('--key', '-k', help='SSH key file')
    parser.add_argument('--hostname', '-H', default='localhost', help='Hostname for report')

    args = parser.parse_args()

    script_dir = Path(__file__).parent
    template_path = Path(args.template) if args.template else script_dir / "CIS_Docker_Benchmark_v1.8.0_SUNET.xlsx"

    if not template_path.exists():
        print(f"Error: Template not found: {template_path}")
        sys.exit(1)

    # Get results
    if args.input:
        print(f"Reading results from: {args.input}")
        with open(args.input, 'r') as f:
            output = f.read()
        results = parse_benchmark_output(output)
    elif args.remote:
        print(f"Running benchmark on: {args.remote}")
        output = run_benchmark_remote(args.remote, args.key)
        results = parse_benchmark_output(output)
    else:
        print("Error: Specify --input or --remote")
        sys.exit(1)

    if not results:
        print("Error: No results found")
        sys.exit(1)

    print(f"Parsed {len(results)} check results")

    # Generate output filename
    date_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    hostname_safe = re.sub(r'[^\w\-]', '_', args.hostname)
    output_filename = f"CIS_Docker_v1.8.0_STIG_{hostname_safe}_{date_str}.xlsx"
    output_path = Path(args.output) / output_filename
    output_path.parent.mkdir(parents=True, exist_ok=True)

    populate_excel(template_path, results, output_path, args.hostname)

    # Summary
    print("\n" + "=" * 50)
    print("STIG-STYLE SUMMARY")
    print("=" * 50)

    counts = {STATUS_NOT_A_FINDING: 0, STATUS_OPEN: 0, STATUS_NOT_APPLICABLE: 0, STATUS_NOT_REVIEWED: 0}
    for result in results.values():
        status = STATUS_MAPPING.get(result['status'], STATUS_NOT_REVIEWED)
        counts[status] = counts.get(status, 0) + 1

    print(f"  {STATUS_NOT_A_FINDING}:  {counts[STATUS_NOT_A_FINDING]}")
    print(f"  {STATUS_OPEN}:                    {counts[STATUS_OPEN]}")
    print(f"  {STATUS_NOT_APPLICABLE}:          {counts[STATUS_NOT_APPLICABLE]}")
    print(f"  {STATUS_NOT_REVIEWED}:            {counts[STATUS_NOT_REVIEWED]}")
    print(f"  {'-' * 35}")
    print(f"  TOTAL:                       {len(results)}")


if __name__ == '__main__':
    main()
