#!/bin/bash

check_2() {
  logit ""
  local id="2"
  local desc="Docker daemon configuration"
  checkHeader="$id - $desc"
  info "$checkHeader"
  startsectionjson "$id" "$desc"
}

check_2_1() {
  local id="2.1"
  local desc="Run the Docker daemon as a non-root user, if possible (Manual)"
  local remediation="Follow the current Docker documentation on how to install the Docker daemon as a non-root user."
  local remediationImpact="There are multiple prerequisites depending on which distribution that is in use, and also known limitations regarding networking and resource limitation. Running in rootless mode also changes the location of any configuration files in use, including all containers using the daemon."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local docker_root_user=$(ps -ef | grep dockerd | grep -v grep | awk '{print $1}' | head -1)
  audit_output "Docker daemon running as user: ${docker_root_user:-unknown}"
  note -c "$check"
  logcheckresult "INFO"
}

check_2_2() {
  local id="2.2"
  local desc="Ensure network traffic is restricted between containers on the default bridge (Manual)"
  local remediation="Edit the Docker daemon configuration file to ensure that inter-container communication is disabled: icc: false."
  local remediationImpact="Inter-container communication is disabled on the default network bridge. If any communication between containers on the same host is desired, it needs to be explicitly defined using container linking or custom networks."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local cmd_output=$(get_docker_effective_command_line_args '--icc')
  local config_output=$(get_docker_configuration_file_args 'icc')
  audit_output "Command line --icc: ${cmd_output:-not set}, Config icc: ${config_output:-not set}"

  if echo "$cmd_output" | grep false >/dev/null 2>&1; then
    pass -s "$check"
    logcheckresult "PASS"
    return
  fi
  if [[ $(echo "$config_output" | grep "false") ]] && [[ $(echo "$config_output" | grep "false") != "null" ]] ; then
    pass -s "$check"
    logcheckresult "PASS"
    return
  fi
  warn -s "$check"
  logcheckresult "WARN"
}

check_2_3() {
  local id="2.3"
  local desc="Ensure the logging level is set to 'info' (Manual)"
  local remediation="Ensure that the Docker daemon configuration file has the following configuration included log-level: info. Alternatively, run the Docker daemon as following: dockerd --log-level=info"
  local remediationImpact="None."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local config_loglevel=$(get_docker_configuration_file_args 'log-level')
  local cmdline_loglevel=$(get_docker_effective_command_line_args '-l')
  audit_output "Config log-level: ${config_loglevel:-not set}, Command line -l: ${cmdline_loglevel:-not set}"

  if get_docker_configuration_file_args 'log-level' >/dev/null 2>&1; then
    if get_docker_configuration_file_args 'log-level' | grep info >/dev/null 2>&1; then
      pass -s "$check"
      logcheckresult "PASS"
      return
    fi
    if [ -z "$(get_docker_configuration_file_args 'log-level')" ]; then
      pass -s "$check"
      logcheckresult "PASS"
      return
    fi
    warn -s "$check"
    logcheckresult "WARN"
    return
  fi
  if get_docker_effective_command_line_args '-l'; then
    if get_docker_effective_command_line_args '-l' | grep "info" >/dev/null 2>&1; then
      pass -s "$check"
      logcheckresult "PASS"
      return
    fi
    warn -s "$check"
    logcheckresult "WARN"
    return
  fi
  pass -s "$check"
  logcheckresult "PASS"
}

check_2_4() {
  local id="2.4"
  local desc="Ensure Docker is allowed to make changes to iptables (Manual)"
  local remediation="Do not run the Docker daemon with --iptables=false option."
  local remediationImpact="The Docker daemon service requires iptables rules to be enabled before it starts."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local cmdline_iptables=$(get_docker_effective_command_line_args '--iptables')
  local config_iptables=$(get_docker_configuration_file_args 'iptables')
  audit_output "Command line --iptables: ${cmdline_iptables:-not set}, Config iptables: ${config_iptables:-not set}"

  if get_docker_effective_command_line_args '--iptables' | grep "false" >/dev/null 2>&1; then
    warn -s "$check"
    logcheckresult "WARN"
    return
  fi
  if [[ $(get_docker_configuration_file_args 'iptables' | grep "false") ]] && [[ $(get_docker_configuration_file_args 'iptables' | grep "false") != "null" ]] ; then
    warn -s "$check"
    logcheckresult "WARN"
    return
  fi
  pass -s "$check"
  logcheckresult "PASS"
}

check_2_5() {
  local id="2.5"
  local desc="Ensure insecure registries are not used (Manual)"
  local remediation="You should ensure that no insecure registries are in use."
  local remediationImpact="None."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local cmdline_insecure=$(get_docker_effective_command_line_args '--insecure-registry')
  local config_insecure=$(get_docker_configuration_file_args 'insecure-registries')
  audit_output "Command line --insecure-registry: ${cmdline_insecure:-not set}, Config insecure-registries: ${config_insecure:-not set}"

  if get_docker_effective_command_line_args '--insecure-registry' | grep "insecure-registry" >/dev/null 2>&1; then
    warn -s "$check"
    logcheckresult "WARN"
    return
  fi
  if [[ $(get_docker_configuration_file_args 'insecure-registries' | grep -v '\[]') ]] && [[ $(get_docker_configuration_file_args 'insecure-registries' | grep -v '\[]') != "null" ]] ; then
    warn -s "$check"
    logcheckresult "WARN"
    return
  fi
  pass -s "$check"
  logcheckresult "PASS"
}

check_2_6() {
  local id="2.6"
  local desc="Ensure aufs storage driver is not used (Manual)"
  local remediation="Do not start Docker daemon as using dockerd --storage-driver aufs option."
  local remediationImpact="aufs is the only storage driver that allows containers to share executable and shared library memory. Its use should be reviewed in line with your organization's security policy."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local storage_driver=$(docker info 2>/dev/null | grep -e "^\s*Storage Driver:" | sed 's/.*Storage Driver:\s*//')
  audit_output "Storage Driver: ${storage_driver:-unknown}"

  if echo "$storage_driver" | grep -i "aufs" >/dev/null 2>&1; then
    warn -s "$check"
    logcheckresult "WARN"
    return
  fi
  pass -s "$check"
  logcheckresult "PASS"
}

check_2_7() {
  local id="2.7"
  local desc="Ensure devicemapper storage driver is not used (Manual)"
  local remediation="Do not start Docker daemon using dockerd --storage-driver devicemapper option."
  local remediationImpact="The devicemapper storage driver is deprecated in favor of overlay2, and has been removed in Docker Engine v25.0. If you are using Device Mapper, you must migrate to a supported storage driver before upgrading to Docker Engine v25.0."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local storage_driver=$(docker info 2>/dev/null | grep -e "^\s*Storage Driver:" | sed 's/.*Storage Driver:\s*//')
  audit_output "Storage Driver: ${storage_driver:-unknown}"

  if echo "$storage_driver" | grep -i "devicemapper" >/dev/null 2>&1; then
    warn -s "$check"
    logcheckresult "WARN"
    return
  fi
  pass -s "$check"
  logcheckresult "PASS"
}

check_2_8() {
  local id="2.8"
  local desc="Ensure TLS authentication for Docker daemon is configured (Manual)"
  local remediation="Follow the steps mentioned in the Docker documentation or other references. By default, TLS authentication is not configured."
  local remediationImpact="You would need to manage and guard certificates and keys for the Docker daemon and Docker clients."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local host_config=$(get_docker_cumulative_command_line_args '-H')
  local tlsverify=$(get_docker_configuration_file_args '"tlsverify":')
  local tls=$(get_docker_configuration_file_args '"tls":')
  audit_output "Host config: ${host_config:-not set}, tlsverify: ${tlsverify:-not set}, tls: ${tls:-not set}"

  if $(grep -qE "host.*tcp://" "$CONFIG_FILE") || \
    [ $(get_docker_cumulative_command_line_args '-H' | grep -vE '(unix|fd)://') > /dev/null 2>&1 ]; then
    if [ $(get_docker_configuration_file_args '"tlsverify":' | grep 'true') ] || \
        [ $(get_docker_cumulative_command_line_args '--tlsverify' | grep 'tlsverify') >/dev/null 2>&1 ]; then
      pass -s "$check"
      logcheckresult "PASS"
      return
    fi
    if [ $(get_docker_configuration_file_args '"tls":' | grep 'true') ] || \
        [ $(get_docker_cumulative_command_line_args '--tls' | grep 'tls$') >/dev/null 2>&1 ]; then
      warn -s "$check"
      warn "     * Docker daemon currently listening on TCP with TLS, but no verification"
      logcheckresult "WARN" "Docker daemon currently listening on TCP with TLS, but no verification"
      return
    fi
    warn -s "$check"
    warn "     * Docker daemon currently listening on TCP without TLS"
    logcheckresult "WARN" "Docker daemon currently listening on TCP without TLS"
    return
  fi
  info -c "$check"
  info "     * Docker daemon not listening on TCP"
  logcheckresult "INFO" "Docker daemon not listening on TCP"
}

check_2_9() {
  local id="2.9"
  local desc="Ensure the default ulimit is configured appropriately (Manual)"
  local remediation="Run Docker in daemon mode and pass --default-ulimit as option with respective ulimits as appropriate in your environment and in line with your security policy. Example: dockerd --default-ulimit nproc=1024:2048 --default-ulimit nofile=100:200"
  local remediationImpact="If ulimits are set incorrectly this could cause issues with system resources, possibly causing a denial of service condition."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local config_ulimit=$(get_docker_configuration_file_args 'default-ulimits')
  local cmdline_ulimit=$(get_docker_effective_command_line_args '--default-ulimit')
  audit_output "Config default-ulimits: ${config_ulimit:-not set}, Command line --default-ulimit: ${cmdline_ulimit:-not set}"

  if [[ $(get_docker_configuration_file_args 'default-ulimits' | grep -v '{}') ]] && [[ $(get_docker_configuration_file_args 'default-ulimits' | grep -v '{}') != "null" ]] ; then
    pass -c "$check"
    logcheckresult "PASS"
    return
  fi
  if get_docker_effective_command_line_args '--default-ulimit' | grep "default-ulimit" >/dev/null 2>&1; then
    pass -c "$check"
    logcheckresult "PASS"
    return
  fi
  info -c "$check"
  info "     * Default ulimit doesn't appear to be set"
  logcheckresult "INFO" "Default ulimit doesn't appear to be set"
}

check_2_10() {
  local id="2.10"
  local desc="Enable user namespace support (Manual)"
  local remediation="Please consult the Docker documentation for various ways in which this can be configured depending upon your requirements. The high-level steps are: Ensure that the files /etc/subuid and /etc/subgid exist. Start the docker daemon with --userns-remap flag."
  local remediationImpact="User namespace remapping is incompatible with a number of Docker features and also currently breaks some of its functionalities."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local config_userns=$(get_docker_configuration_file_args 'userns-remap')
  local cmdline_userns=$(get_docker_effective_command_line_args '--userns-remap')
  audit_output "Config userns-remap: ${config_userns:-not set}, Command line --userns-remap: ${cmdline_userns:-not set}"

  if [[ $(get_docker_configuration_file_args 'userns-remap' | grep -v '""') ]] && [[ $(get_docker_configuration_file_args 'userns-remap' | grep -v '""') != "null" ]] ; then
    pass -s "$check"
    logcheckresult "PASS"
    return
  fi
  if get_docker_effective_command_line_args '--userns-remap' | grep "userns-remap" >/dev/null 2>&1; then
    pass -s "$check"
    logcheckresult "PASS"
    return
  fi
  warn -s "$check"
  logcheckresult "WARN"
}

check_2_11() {
  local id="2.11"
  local desc="Ensure the default cgroup usage has been confirmed (Manual)"
  local remediation="The default setting is in line with good security practice and can be left in situ."
  local remediationImpact="None."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local config_cgroup=$(get_docker_configuration_file_args 'cgroup-parent')
  local cmdline_cgroup=$(get_docker_effective_command_line_args '--cgroup-parent')
  audit_output "Config cgroup-parent: ${config_cgroup:-not set}, Command line --cgroup-parent: ${cmdline_cgroup:-not set}"

  if get_docker_configuration_file_args 'cgroup-parent' | grep -v ''; then
    warn -s "$check"
    info "     * Confirm cgroup usage"
    logcheckresult "WARN" "Confirm cgroup usage"
    return
  fi
  if get_docker_effective_command_line_args '--cgroup-parent' | grep "cgroup-parent" >/dev/null 2>&1; then
    warn -s "$check"
    info "     * Confirm cgroup usage"
    logcheckresult "WARN" "Confirm cgroup usage"
    return
  fi
  pass -s "$check"
  logcheckresult "PASS"
}

check_2_12() {
  local id="2.12"
  local desc="Ensure base device size is not changed until needed (Manual)"
  local remediation="Do not set --storage-opt dm.basesize until needed."
  local remediationImpact="None."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local config_storage=$(get_docker_configuration_file_args 'storage-opts')
  local cmdline_storage=$(get_docker_effective_command_line_args '--storage-opt')
  audit_output "Config storage-opts: ${config_storage:-not set}, Command line --storage-opt: ${cmdline_storage:-not set}"

  if get_docker_configuration_file_args 'storage-opts' | grep "dm.basesize" >/dev/null 2>&1; then
    warn -s "$check"
    logcheckresult "WARN"
    return
  fi
  if get_docker_effective_command_line_args '--storage-opt' | grep "dm.basesize" >/dev/null 2>&1; then
    warn -s "$check"
    logcheckresult "WARN"
    return
  fi
  pass -s "$check"
  logcheckresult "PASS"
}

check_2_13() {
  local id="2.13"
  local desc="Ensure that authorization for Docker client commands is enabled (Manual)"
  local remediation="Install/Create an authorization plugin. Configure the authorization policy as desired. Start the docker daemon using command dockerd --authorization-plugin=<PLUGIN_ID>"
  local remediationImpact="Each Docker command needs to pass through the authorization plugin mechanism. This may have a performance impact"
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local config_authz=$(get_docker_configuration_file_args 'authorization-plugins')
  local cmdline_authz=$(get_docker_effective_command_line_args '--authorization-plugin')
  audit_output "Config authorization-plugins: ${config_authz:-not set}, Command line --authorization-plugin: ${cmdline_authz:-not set}"

  if [[ $(get_docker_configuration_file_args 'authorization-plugins' | grep -v '\[]') ]] && [[ $(get_docker_configuration_file_args 'authorization-plugins' | grep -v '\[]') != "null" ]] ; then
    pass -s "$check"
    logcheckresult "PASS"
    return
  fi
  if get_docker_effective_command_line_args '--authorization-plugin' | grep "authorization-plugin" >/dev/null 2>&1; then
    pass -s "$check"
    logcheckresult "PASS"
    return
  fi
  warn -s "$check"
  logcheckresult "WARN"
}

check_2_14() {
  local id="2.14"
  local desc="Ensure centralized and remote logging is configured (Manual)"
  local remediation="Set up the desired log driver following its documentation. Start the docker daemon using that logging driver. Example: dockerd --log-driver=syslog --log-opt syslog-address=tcp://192.xxx.xxx.xxx"
  local remediationImpact="None."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local logging_driver=$(docker info --format '{{ .LoggingDriver }}' 2>/dev/null)
  audit_output "Logging Driver: ${logging_driver:-unknown}"

  if echo "$logging_driver" | grep 'json-file' >/dev/null 2>&1; then
    warn -s "$check"
    logcheckresult "WARN"
    return
  fi
  pass -s "$check"
  logcheckresult "PASS"
}

check_2_15() {
  local id="2.15"
  local desc="Ensure containers are restricted from acquiring new privileges (Manual)"
  local remediation="You should run the Docker daemon using command: dockerd --no-new-privileges"
  local remediationImpact="no_new_priv prevents LSMs such as SELinux from escalating the privileges of individual containers."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local cmdline_newnp=$(get_docker_effective_command_line_args '--no-new-privileges')
  local config_newnp=$(get_docker_configuration_file_args 'no-new-privileges')
  audit_output "Command line --no-new-privileges: ${cmdline_newnp:-not set}, Config no-new-privileges: ${config_newnp:-not set}"

  if get_docker_effective_command_line_args '--no-new-privileges' | grep "no-new-privileges" >/dev/null 2>&1; then
    pass -s "$check"
    logcheckresult "PASS"
    return
  fi
  if get_docker_configuration_file_args 'no-new-privileges' | grep true >/dev/null 2>&1; then
    pass -s "$check"
    logcheckresult "PASS"
    return
  fi
  warn -s "$check"
  logcheckresult "WARN"
}

check_2_16() {
  local id="2.16"
  local desc="Ensure live restore is enabled (Manual)"
  local remediation="Run Docker in daemon mode and pass --live-restore option."
  local remediationImpact="None."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local live_restore=$(docker info 2>/dev/null | grep -e "Live Restore Enabled:" | sed 's/.*Live Restore Enabled:\s*//')
  local swarm_status=$(docker info 2>/dev/null | grep -e "Swarm:" | sed 's/.*Swarm:\s*//')
  audit_output "Live Restore Enabled: ${live_restore:-unknown}, Swarm: ${swarm_status:-unknown}"

  if echo "$live_restore" | grep -i "true" >/dev/null 2>&1; then
    pass -s "$check"
    logcheckresult "PASS"
    return
  fi
  if echo "$swarm_status" | grep -i "active" >/dev/null 2>&1; then
    pass -s "$check (Incompatible with swarm mode)"
    logcheckresult "PASS"
    return
  fi
  if get_docker_effective_command_line_args '--live-restore' | grep "live-restore" >/dev/null 2>&1; then
    pass -s "$check"
    logcheckresult "PASS"
    return
  fi
  warn -s "$check"
  logcheckresult "WARN"
}

check_2_17() {
  local id="2.17"
  local desc="Ensure Userland Proxy is Disabled (Manual)"
  local remediation="You should run the Docker daemon using command: dockerd --userland-proxy=false"
  local remediationImpact="Some systems with older Linux kernels may not be able to support hairpin NAT and therefore require the userland proxy service. Also, some networking setups can be impacted by the removal of the userland proxy."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local config_proxy=$(get_docker_configuration_file_args 'userland-proxy')
  local cmdline_proxy=$(get_docker_effective_command_line_args '--userland-proxy')
  audit_output "Config userland-proxy: ${config_proxy:-not set}, Command line --userland-proxy: ${cmdline_proxy:-not set}"

  if get_docker_configuration_file_args 'userland-proxy' | grep false >/dev/null 2>&1; then
    pass -s "$check"
    logcheckresult "PASS"
    return
  fi
  if get_docker_effective_command_line_args '--userland-proxy=false' 2>/dev/null | grep "userland-proxy=false" >/dev/null 2>&1; then
    pass -s "$check"
    logcheckresult "PASS"
    return
  fi
  warn -s "$check"
  logcheckresult "WARN"
}

check_2_18() {
  local id="2.18"
  local desc="Ensure that a daemon-wide custom seccomp profile is applied if appropriate (Manual)"
  local remediation="By default, Docker's default seccomp profile is applied. If this is adequate for your environment, no action is necessary."
  local remediationImpact="A misconfigured seccomp profile could possibly interrupt your container environment. You should therefore exercise extreme care if you choose to override the default settings."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local security_opts=$(docker info --format '{{ .SecurityOptions }}' 2>/dev/null)
  audit_output "Security Options: ${security_opts:-unknown}"

  if docker info --format '{{ .SecurityOptions }}' | grep 'name=seccomp,profile=default' 2>/dev/null 1>&2; then
    pass -c "$check"
    logcheckresult "PASS"
    return
  fi
  info -c "$check"
  logcheckresult "INFO"
}

check_2_19() {
  docker_version=$(docker version | grep -i -A2 '^server' | grep ' Version:' \
    | awk '{print $NF; exit}' | tr -d '[:alpha:]-,.' | cut -c 1-4)

  local id="2.19"
  local desc="Ensure that experimental features are not implemented in production (Manual)"
  local remediation="You should not pass --experimental as a runtime parameter to the Docker daemon on production systems."
  local remediationImpact="None."
  local check="$id - $desc"
  starttestjson "$id" "$desc"

  local experimental=$(docker version -f '{{.Server.Experimental}}' 2>/dev/null)
  audit_output "Docker version: $docker_version, Experimental: ${experimental:-unknown}"

  if [ "$docker_version" -le 1903 ]; then
    if docker version -f '{{.Server.Experimental}}' | grep false 2>/dev/null 1>&2; then
      pass -s "$check"
      logcheckresult "PASS"
      return
    fi
    warn -s "$check"
    logcheckresult "WARN"
    return
  fi
  local desc="$desc (Deprecated)"
  local check="$id - $desc"
  info -c "$check"
  logcheckresult "INFO"
}

check_2_end() {
  endsectionjson
}
